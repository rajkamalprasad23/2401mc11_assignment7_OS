# Q2 semaphore kernel changes — xv6-public

## API additions
Add unused syscall numbers and plumbing in syscall.h, syscall.c, sysproc.c, user.h and usys.S:
```c
int sem_init(int sem_id, int value);
int sem_wait(int sem_id);
int sem_signal(int sem_id);
```
Use `argint()` in the sys_* wrappers to fetch integer arguments and validate `0 <= sem_id < NSEMS`.

## Data structure (e.g. in a new sem.c, with declarations in defs.h)
```c
#define NSEMS 10
struct semaphore {
  struct spinlock lk;
  int value;
  int initialized;
};
static struct semaphore semaphores[NSEMS];
```
Initialize each semaphore's spinlock exactly once during kernel initialization (e.g. from `main()` after `kinit()`), not every time `sem_init()` is called. Reinitializing a semaphore concurrently with waiters is invalid.

## Correct blocking algorithm
Use xv6's `sleep(chan, lock)` and `wakeup(chan)`. A simple nonnegative-count semaphore implementation is:
```c
int sem_wait(int id) {
  struct semaphore *s;
  if (id < 0 || id >= NSEMS || !s->initialized) return -1;
  acquire(&s->lk);
  while (s->value == 0)
    sleep(s, &s->lk);
  s->value--;
  release(&s->lk);
  return 0;
}
int sem_signal(int id) {
  struct semaphore *s;
  if (id < 0 || id >= NSEMS || !s->initialized) return -1;
  acquire(&s->lk);
  s->value++;
  wakeup(s);
  release(&s->lk);
  return 0;
}
```
This is a counting semaphore where `value` never becomes negative; it is equivalent in behavior to blocking while a zero count is unavailable. It is safer than decrementing below zero unless a separate waiter count is also maintained.
Use a global table lock to protect initialization metadata if `initialized` can be read/written concurrently. Do not acquire locks in inconsistent order.

## Initialization
At boot, initialize a global table lock if used and each `semaphores[i].lk` using `initlock()`. `sem_init(id, initial)` should reject invalid IDs and negative values, then set `value` and `initialized` under the table/entry lock. For the assignment tests, initialize before creating worker threads.

## Critical details
- `sleep(chan, &s->lk)` atomically releases s->lk while sleeping and reacquires it before returning.
- Always use `while`, not `if`, when checking the condition after wakeup.
- Do not hold a spinlock while printing or doing unrelated work.
- In the user tests, check syscall return values so a broken syscall is visible.
- The supplied user test assumes Q1's clone/join implementation exists.
