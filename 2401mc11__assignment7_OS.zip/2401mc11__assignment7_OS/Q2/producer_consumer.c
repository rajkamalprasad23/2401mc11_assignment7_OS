#include "types.h"
#include "stat.h"
#include "user.h"

#define BUFSIZE 5
#define ITEMS 20
#define SEM_EMPTY 1
#define SEM_FULL  2
#define SEM_MUTEX 3

static int buffer[BUFSIZE];
static int in = 0, out = 0;

static void producer(void *arg)
{
  int i;
  (void)arg;
  for(i = 1; i <= ITEMS; i++) {
    sem_wait(SEM_EMPTY);
    sem_wait(SEM_MUTEX);

    buffer[in] = i;
    printf(1, "produced %d\n", i);
    in = (in + 1) % BUFSIZE;

    sem_signal(SEM_MUTEX);
    sem_signal(SEM_FULL);
  }
  exit();
}

static void consumer(void *arg)
{
  int i, item;
  (void)arg;
  for(i = 0; i < ITEMS; i++) {
    sem_wait(SEM_FULL);
    sem_wait(SEM_MUTEX);

    item = buffer[out];
    out = (out + 1) % BUFSIZE;
    printf(1, "consumed %d\n", item);

    sem_signal(SEM_MUTEX);
    sem_signal(SEM_EMPTY);
  }
  exit();
}

int
main(void)
{
  void *ps, *cs;

  if(sem_init(SEM_EMPTY, BUFSIZE) < 0 ||
     sem_init(SEM_FULL, 0) < 0 ||
     sem_init(SEM_MUTEX, 1) < 0) {
    printf(2, "producer_consumer: sem_init failed\n");
    exit();
  }

  ps = malloc(4096);
  cs = malloc(4096);
  if(ps == 0 || cs == 0) {
    printf(2, "producer_consumer: stack allocation failed\n");
    exit();
  }

  if(clone(producer, 0, (char*)ps + 4096) < 0 ||
     clone(consumer, 0, (char*)cs + 4096) < 0) {
    printf(2, "producer_consumer: clone failed\n");
    exit();
  }

  join();
  join();
  free(ps);
  free(cs);
  exit();
}
