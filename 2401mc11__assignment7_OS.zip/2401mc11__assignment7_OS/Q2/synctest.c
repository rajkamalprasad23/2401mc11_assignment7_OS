#include "types.h"
#include "stat.h"
#include "user.h"

#define NTHREADS 3
#define ITERATIONS 100000
#define MUTEX_SEM 0

volatile int counter = 0;

static void worker(void *arg)
{
  int i;
  (void)arg;

  for(i = 0; i < ITERATIONS; i++) {
    if(sem_wait(MUTEX_SEM) < 0) {
      printf(2, "synctest: sem_wait failed\n");
      exit();
    }
    counter++;
    if(sem_signal(MUTEX_SEM) < 0) {
      printf(2, "synctest: sem_signal failed\n");
      exit();
    }
  }
  exit();
}

int
main(void)
{
  int i;
  void *stacks[NTHREADS];

  if(sem_init(MUTEX_SEM, 1) < 0) {
    printf(2, "synctest: sem_init failed\n");
    exit();
  }

  for(i = 0; i < NTHREADS; i++) {
    stacks[i] = malloc(4096);
    if(stacks[i] == 0 || clone(worker, 0, (char*)stacks[i] + 4096) < 0) {
      printf(2, "synctest: stack/clone failed\n");
      exit();
    }
  }

  for(i = 0; i < NTHREADS; i++)
    join();

  printf(1, "expected counter: %d\n", NTHREADS * ITERATIONS);
  printf(1, "actual counter:   %d\n", counter);

  for(i = 0; i < NTHREADS; i++)
    free(stacks[i]);
  exit();
}
