# Q1 kernel changes — classic x86 xv6-public

These are integration requirements, not complete drop-in replacements for whole kernel files.
Keep your local xv6 code and merge carefully.

## 1. proc.h: record shared address-space ownership
Add fields to `struct proc`:
```c
int is_thread;             // 1 for clone-created thread
struct proc *tg_leader;    // process that owns the shared address space
int tid;                   // optional: useful for debugging
```
Initialize these fields in `allocproc()` / process creation paths. For a normal process:
`is_thread = 0`, `tg_leader = p`.

A more robust design uses a separate address-space object with a reference count. A leader pointer alone
is not enough if the leader exits before every thread has finished.

## 2. syscall numbers and stubs
In `syscall.h`, assign unused syscall numbers:
```c
#define SYS_clone  22
#define SYS_join   23
```
Check that these numbers are unused in your checkout. In `syscall.c`, add:
```c
extern int sys_clone(void);
extern int sys_join(void);
/* Add [SYS_clone] sys_clone, [SYS_join] sys_join to syscalls[] */
```
In `user.h`:
```c
int clone(void (*fcn)(void*), void *arg, void *stack);
int join(void);
```
In `usys.S`:
```asm
SYSCALL(clone)
SYSCALL(join)
```
In `sysproc.c`, implement argument extraction:
```c
int
sys_clone(void)
{
  void (*fcn)(void*);
  void *arg, *stack;
  if(argptr(0, (char**)&fcn, sizeof(fcn)) < 0 ||
     argptr(1, (char**)&arg, sizeof(arg)) < 0 ||
     argptr(2, (char**)&stack, sizeof(stack)) < 0)
    return -1;
  return clone(fcn, arg, stack);
}
```
`sys_join()` should call the kernel `join()` routine and return the joined thread's PID or -1.

## 3. proc.c: clone() setup
Implement `clone(void (*fcn)(void*), void *arg, void *stack)` in the kernel. The intended steps:
1. Validate that `stack` is a valid user address and has enough writable user memory for the initial stack frame.
2. Call `allocproc()` to obtain a new proc and its own kernel stack.
3. Share the caller's `pgdir` (do NOT call `copyuvm()`), and ensure the page-directory lifetime is reference-counted.
4. Copy the caller's trapframe, then set the child `eax = 0`.
5. Build the user stack at the supplied stack top. Push a fake return PC (e.g. 0xffffffff), then `arg`,
   then set `eip = (uint)fcn` and `esp` to the resulting stack pointer. On x86, cdecl expects arg at
   `esp+4` after the return address.
6. Set thread ownership metadata, parent relationship, state RUNNABLE, and return child PID.
7. On any failure, unwind locks/resources without freeing a pgdir still used by another thread.

Pseudo-layout for stack setup:
```c
uint sp = (uint)stack;
sp -= sizeof(uint); *(uint*)sp = 0xffffffff; // return address if fcn returns
sp -= sizeof(void*); *(void**)sp = arg;
np->tf->eip = (uint)fcn;
np->tf->esp = sp;
```
Do not dereference user pointers in kernel without validating them first. In production-quality code, copyout()
or a carefully validated address range should be used instead of raw kernel writes to a user virtual address.

## 4. join(), exit(), wait(), fork()
- `join()` sleeps until a child thread is ZOMBIE, reaps its kernel stack/process slot, and returns its PID.
- `exit()` for a thread must NOT free the shared page directory. Only the last owner may free it.
- `wait()` should reap ordinary child processes, not accidentally free/reap threads that the caller expects to collect via `join()`.
- `fork()` should copy the process address space as usual, producing an independent process. Do not copy thread metadata so the new process accidentally shares the old pgdir.
- Ensure every sleep/wakeup path follows xv6's `ptable.lock` conventions.
- Do not let a thread be reaped twice by both wait() and join().

## 5. Memory and synchronization limitations
The user-provided stack must be separately allocated for each thread and remain allocated until join() returns.
The assignment's unsynchronized increment is a C data race; the observed result may be 300000 on some runs,
so do not claim it must always be less. Repeat the test or add logging if the race is not visible.
