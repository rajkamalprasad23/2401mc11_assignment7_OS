/* Q1 additions for standard MIT xv6-public (x86).
   1) Add declarations with the other extern syscall declarations:
       extern int sys_clone(void);
       extern int sys_join(void);

   2) Add these entries to the syscall dispatch table:
       [SYS_clone] sys_clone,
       [SYS_join]  sys_join,

   Keep the existing entries and their order unchanged.
