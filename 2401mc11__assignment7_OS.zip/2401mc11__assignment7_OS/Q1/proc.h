/* Q1 additions for standard MIT xv6-public (x86).
   Insert these fields inside struct proc, before the closing brace. */

  int is_thread;              // 1 if this process is a thread
  struct proc *tg_leader;     // process that owns the shared address space
  int thread_count;           // live threads belonging to the leader
