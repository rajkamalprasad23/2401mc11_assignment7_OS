#include "types.h"
#include "stat.h"
#include "user.h"

#define NTHREADS 3
#define ITERATIONS 100000

volatile int counter = 0;

/* Each thread starts here with arg pointing to its integer ID. */
static void worker(void *arg)
{
  int id = *(int*)arg;
  int i;

  for(i = 0; i < ITERATIONS; i++)
    counter++;  /* Intentionally unsynchronized: race condition for Q1. */

  printf(1, "thread %d finished\n", id);
  exit();
}

int
main(void)
{
  int ids[NTHREADS];
  int i;
  void *stacks[NTHREADS];

  for(i = 0; i < NTHREADS; i++) {
    stacks[i] = malloc(4096);
    if(stacks[i] == 0) {
      printf(2, "threadtest: stack allocation failed\n");
      exit();
    }
    ids[i] = i;
    /* Stack grows downward on x86; pass the top of the allocated stack. */
    if(clone(worker, &ids[i], (char*)stacks[i] + 4096) < 0) {
      printf(2, "threadtest: clone failed\n");
      exit();
    }
  }

  for(i = 0; i < NTHREADS; i++)
    if(join() < 0)
      printf(2, "threadtest: join failed\n");

  printf(1, "expected counter (without race): %d\n", NTHREADS * ITERATIONS);
  printf(1, "actual shared counter: %d\n", counter);

  for(i = 0; i < NTHREADS; i++)
    free(stacks[i]);

  exit();
}
