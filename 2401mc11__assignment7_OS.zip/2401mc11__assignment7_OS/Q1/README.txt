Q1 xv6-public (x86) modified-file fragments

These are actual .c/.h/.S source files containing the Question 1 code and
integration edits for the standard MIT xv6-public x86 source tree.

Important: proc.c, syscall.c, syscall.h, defs.h, sysproc.c, user.h and usys.S
are provided as source fragments/additions, not complete replacements for
the upstream files. Merge the indicated code into the original files; do not
overwrite the full upstream files with these fragments. This is untested.
