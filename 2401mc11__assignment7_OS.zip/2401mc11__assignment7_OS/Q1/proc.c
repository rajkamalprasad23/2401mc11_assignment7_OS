/* Q1 implementation additions for standard MIT xv6-public (x86).
   These are the functions/edits to merge into the original proc.c.
   They are intentionally supplied as a C source fragment, not as a
   replacement for all 507 lines of the upstream proc.c. */

int
clone(void (*fcn)(void*), void *arg, void *stack)
{
  int i, pid;
  uint sp, retaddr;
  struct proc *np;
  struct proc *curproc = myproc();

  /* Keep the initial implementation simple: only the process leader
     creates threads. */
  if(curproc->is_thread || fcn == 0 || stack == 0)
    return -1;
  if((uint)fcn >= curproc->sz ||
     (uint)stack > curproc->sz ||
     (uint)stack < 2*sizeof(uint))
    return -1;
  if(arg != 0 && (uint)arg >= curproc->sz)
    return -1;
  if(uva2ka(curproc->pgdir, (char*)fcn) == 0)
    return -1;

  if((np = allocproc()) == 0)
    return -1;

  /* Threads share the address space; never free this pgdir from a thread. */
  np->pgdir = curproc->pgdir;
  np->sz = curproc->sz;
  *np->tf = *curproc->tf;

  /* Stack layout at function entry: [return address][arg]. */
  sp = (uint)stack;
  sp -= sizeof(uint);
  if(copyout(np->pgdir, sp, (char*)&arg, sizeof(uint)) < 0)
    goto bad;
  sp -= sizeof(uint);
  retaddr = 0xffffffff;
  if(copyout(np->pgdir, sp, (char*)&retaddr, sizeof(uint)) < 0)
    goto bad;

  np->tf->eip = (uint)fcn;
  np->tf->esp = sp;
  np->tf->eax = 0;
  np->parent = curproc;
  np->is_thread = 1;
  np->tg_leader = curproc;
  safestrcpy(np->name, curproc->name, sizeof(np->name));

  for(i = 0; i < NOFILE; i++)
    if(curproc->ofile[i])
      np->ofile[i] = filedup(curproc->ofile[i]);
  np->cwd = idup(curproc->cwd);

  pid = np->pid;
  acquire(&ptable.lock);
  curproc->thread_count++;
  np->state = RUNNABLE;
  release(&ptable.lock);
  return pid;

bad:
  kfree(np->kstack);
  np->kstack = 0;
  acquire(&ptable.lock);
  np->pgdir = 0;
  np->parent = 0;
  np->state = UNUSED;
  release(&ptable.lock);
  return -1;
}

int
join(void)
{
  struct proc *p;
  int have_threads, pid;
  struct proc *curproc = myproc();

  if(curproc->is_thread)
    return -1;

  acquire(&ptable.lock);
  for(;;){
    have_threads = 0;
    for(p = ptable.proc; p < &ptable.proc[NPROC]; p++){
      if(p->parent != curproc || !p->is_thread)
        continue;
      have_threads = 1;
      if(p->state == ZOMBIE){
        pid = p->pid;
        kfree(p->kstack);
        p->kstack = 0;
        /* Shared pgdir belongs to the process leader: do not free it. */
        p->pgdir = 0;
        p->pid = 0;
        p->parent = 0;
        p->name[0] = 0;
        p->killed = 0;
        p->is_thread = 0;
        p->tg_leader = 0;
        p->thread_count = 0;
        p->state = UNUSED;
        release(&ptable.lock);
        return pid;
      }
    }
    if(!have_threads || curproc->killed){
      release(&ptable.lock);
      return -1;
    }
    sleep(curproc, &ptable.lock);
  }
}

/* Required edits to existing functions in proc.c:

1. In allocproc(), initialize the new fields after assigning p->pid:
     p->is_thread = 0;
     p->tg_leader = p;
     p->thread_count = 0;

2. In growproc(), reject address-space resizing while a process has
   threads sharing its page table. Add after curproc = myproc():
     if(curproc->is_thread || curproc->thread_count > 0)
       return -1;

3. In fork(), after np->parent = curproc, add:
     np->is_thread = 0;
     np->tg_leader = np;
     np->thread_count = 0;

4. At the beginning of exit(), before closing files, make a leader wait
   for all active threads to finish:
     if(!curproc->is_thread){
       acquire(&ptable.lock);
       while(curproc->thread_count > 0)
         sleep(curproc, &ptable.lock);
       release(&ptable.lock);
     }

5. In exit(), after acquire(&ptable.lock) and before waking the parent,
   add:
     if(curproc->is_thread && curproc->tg_leader){
       curproc->tg_leader->thread_count--;
       wakeup1(curproc->tg_leader);
       curproc->tg_leader = 0;
     }

6. In wait(), before setting havekids = 1, skip thread children:
     if(p->is_thread)
       continue;

7. The join() function above reaps thread children. Ensure the original
   wait() function continues to call freevm(p->pgdir) only for normal
   process children (thread children are skipped by wait()).
*/
