/* Q1 additions for standard MIT xv6-public (x86).
   Append after the last existing syscall number. */

#define SYS_clone 22
#define SYS_join  23
