/* Q1 additions for standard MIT xv6-public (x86).
   Add these declarations in the process management section. */

int             clone(void (*fcn)(void*), void *arg, void *stack);
int             join(void);
