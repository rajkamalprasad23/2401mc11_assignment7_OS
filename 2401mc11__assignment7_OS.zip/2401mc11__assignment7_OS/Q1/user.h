/* Q1 additions for standard MIT xv6-public (x86).
   Add alongside the existing process-related user declarations. */

int clone(void (*fcn)(void*), void *arg, void *stack);
int join(void);
