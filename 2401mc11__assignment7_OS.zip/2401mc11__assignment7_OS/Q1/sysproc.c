/* Q1 additions for standard MIT xv6-public (x86).
   Append these wrappers to sysproc.c. */

int
sys_clone(void)
{
  int fcn, arg, stack;

  if(argint(0, &fcn) < 0 ||
     argint(1, &arg) < 0 ||
     argint(2, &stack) < 0)
    return -1;

  return clone((void (*)(void*))(uint)fcn,
               (void*)(uint)arg,
               (void*)(uint)stack);
}

int
sys_join(void)
{
  return join();
}
