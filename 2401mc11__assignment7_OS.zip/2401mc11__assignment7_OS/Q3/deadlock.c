#include "types.h"
#include "stat.h"
#include "user.h"

#define MAXP 5
#define MAXR 4

static int allocation[MAXP][MAXR];
static int request[MAXP][MAXR];
static int available[MAXR];
static int n, m;

static void print_state(int work[MAXR], int finish[MAXP])
{
  int i, j;
  printf(1, "Available/Work: ");
  for(j = 0; j < m; j++) printf(1, "%d ", work[j]);
  printf(1, "\n");
  printf(1, "Finished: ");
  for(i = 0; i < n; i++) printf(1, "P%d=%d ", i, finish[i]);
  printf(1, "\n");
}

/* Returns number of deadlocked processes and writes their IDs to deadlocked[]. */
static int detect_deadlock(int deadlocked[MAXP])
{
  int work[MAXR], finish[MAXP];
  int i, j, progress, count = 0;

  for(j = 0; j < m; j++) work[j] = available[j];
  for(i = 0; i < n; i++) {
    finish[i] = 1;
    for(j = 0; j < m; j++)
      if(allocation[i][j] != 0) finish[i] = 0;
  }

  do {
    progress = 0;
    for(i = 0; i < n; i++) {
      int can_finish = 1;
      if(finish[i]) continue;
      for(j = 0; j < m; j++)
        if(request[i][j] > work[j]) { can_finish = 0; break; }
      if(can_finish) {
        for(j = 0; j < m; j++) work[j] += allocation[i][j];
        finish[i] = 1;
        progress = 1;
        printf(1, "P%d can finish; ", i);
        print_state(work, finish);
      }
    }
  } while(progress);

  for(i = 0; i < n; i++)
    if(!finish[i]) deadlocked[count++] = i;
  return count;
}

/* Banker's safety check. Need = Max - Allocation. */
static int is_safe_state(int maxm[MAXP][MAXR])
{
  int work[MAXR], finish[MAXP];
  int i, j, progress, completed = 0;

  for(j = 0; j < m; j++) work[j] = available[j];
  for(i = 0; i < n; i++) finish[i] = 0;

  do {
    progress = 0;
    for(i = 0; i < n; i++) {
      int can_finish = 1;
      if(finish[i]) continue;
      for(j = 0; j < m; j++) {
        int need = maxm[i][j] - allocation[i][j];
        if(need < 0 || need > work[j]) { can_finish = 0; break; }
      }
      if(can_finish) {
        for(j = 0; j < m; j++) work[j] += allocation[i][j];
        finish[i] = 1;
        completed++;
        progress = 1;
      }
    }
  } while(progress);

  return completed == n;
}

static void run_case(char *name, int alloc[MAXP][MAXR],
                     int req[MAXP][MAXR], int avail[MAXR],
                     int maxm[MAXP][MAXR], int procs, int resources)
{
  int i, j, dead[MAXP], count;
  n = procs; m = resources;
  for(i = 0; i < n; i++)
    for(j = 0; j < m; j++) {
      allocation[i][j] = alloc[i][j];
      request[i][j] = req[i][j];
    }
  for(j = 0; j < m; j++) available[j] = avail[j];

  printf(1, "\n=== %s ===\n", name);
  count = detect_deadlock(dead);
  if(count == 0) printf(1, "Deadlock detection: no deadlocked processes\n");
  else {
    printf(1, "Deadlocked processes: ");
    for(i = 0; i < count; i++) printf(1, "P%d ", dead[i]);
    printf(1, "\n");
  }
  printf(1, "Banker's safe state: %s\n", is_safe_state(maxm) ? "YES" : "NO");
}

int
main(void)
{
  /* Case 1: deadlock: P0 holds R0 requests R1; P1 holds R1 requests R0. */
  int a1[MAXP][MAXR] = {{1,0},{0,1}};
  int r1[MAXP][MAXR] = {{0,1},{1,0}};
  int v1[MAXR] = {0,0};
  int x1[MAXP][MAXR] = {{1,1},{1,1}};

  /* Case 2: safe: P0 can finish with R0 available, then releases resources. */
  int a2[MAXP][MAXR] = {{1,0},{0,1}};
  int r2[MAXP][MAXR] = {{0,0},{1,0}};
  int v2[MAXR] = {1,0};
  int x2[MAXP][MAXR] = {{1,0},{1,1}};

  /* Case 3: unsafe: no available resources, both processes still need the other. */
  int a3[MAXP][MAXR] = {{1,0},{0,1}};
  int r3[MAXP][MAXR] = {{0,1},{1,0}};
  int v3[MAXR] = {0,0};
  int x3[MAXP][MAXR] = {{1,1},{1,1}};

  run_case("Case 1: circular wait", a1, r1, v1, x1, 2, 2);
  run_case("Case 2: safe completion", a2, r2, v2, x2, 2, 2);
  run_case("Case 3: unsafe/deadlocked", a3, r3, v3, x3, 2, 2);

  printf(1, "\nNote: this program simulates resource matrices. It does not itself create a real pipe deadlock.\n");
  exit();
}
