#include "types.h"
#include "stat.h"
#include "user.h"

#define NPROC 4
#define WORK 12000000

static void burn(int pid)
{
  volatile int x = 0;
  int i;
  for(i = 0; i < WORK; i++)
    x = x + (i ^ pid) % 7;
  printf(1, "process pid=%d completed (checksum=%d)\n", pid, x);
}

int
main(void)
{
  int priorities[NPROC] = {1, 5, 10, 20};
  int i, pid;

  for(i = 0; i < NPROC; i++) {
    pid = fork();
    if(pid < 0) {
      printf(2, "priotest: fork failed\n");
      exit();
    }
    if(pid == 0) {
      /* Child sets its own priority after fork. */
      if(set_priority(getpid(), priorities[i]) < 0)
        printf(2, "priotest: set_priority failed for pid %d\n", getpid());
      printf(1, "started pid=%d priority=%d\n", getpid(), get_priority(getpid()));
      burn(getpid());
      exit();
    }
  }

  for(i = 0; i < NPROC; i++)
    wait();

  printf(1, "priotest: all children completed\n");
  exit();
}
