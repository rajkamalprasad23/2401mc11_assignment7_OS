# Q4 priority scheduler with aging — xv6-public

## proc.h
Add to `struct proc`:
```c
int priority;       // 1 highest, 20 lowest
int wait_ticks;     // RUNNABLE ticks since last scheduled
```
Set `priority = 10` and `wait_ticks = 0` for each newly created process in `allocproc()`.
When a process is forked, the assignment may either inherit the parent's priority or reset to 10; choose one
policy and document it. This template expects each test child to call set_priority() explicitly.

## syscalls
Add unused numbers in syscall.h:
```c
#define SYS_set_priority 24
#define SYS_get_priority 25
```
Check for collisions. Add user prototypes to user.h:
```c
int set_priority(int pid, int priority);
int get_priority(int pid);
```
Add `SYSCALL(set_priority)` and `SYSCALL(get_priority)` to usys.S; add `sys_set_priority` and
`sys_get_priority` to syscall.c's dispatch table. In sysproc.c:
```c
int sys_set_priority(void) {
  int pid, priority;
  if(argint(0, &pid) < 0 || argint(1, &priority) < 0) return -1;
  return set_priority(pid, priority);
}
int sys_get_priority(void) {
  int pid;
  if(argint(0, &pid) < 0) return -1;
  return get_priority(pid);
}
```
Implement kernel `set_priority(pid, priority)` and `get_priority(pid)` in proc.c. Validate priority in [1,20].
Protect process-table traversal with `ptable.lock`. Return -1 if PID doesn't exist.

## scheduler() selection
Classic xv6's scheduler() holds `ptable.lock` while scanning. Instead of immediately running each RUNNABLE
process, select the RUNNABLE process with the smallest numeric priority. To preserve approximate round-robin
among ties, maintain a rotating scan start or a last-selected index and scan cyclically from the next slot.
Do not hold ptable.lock across a context switch in a way that violates xv6's existing scheduler invariants.

Conceptual selection:
```c
best = -1;
for (k = 0; k < NPROC; k++) {
  i = (scan_start + k) % NPROC;
  p = &ptable.proc[i];
  if (p->state == RUNNABLE &&
      (best == -1 || p->priority < ptable.proc[best].priority))
    best = i;
}
if (best >= 0) {
  p = &ptable.proc[best];
  scan_start = (best + 1) % NPROC;
  /* preserve original xv6 switch/curproc setup for selected p */
}
```
Tie handling requires comparing equal priorities in the cyclic scan order, not replacing `best` on equality.

## Aging
The assignment specifies: if a RUNNABLE process waits more than 30 ticks without being scheduled,
increase its priority by decrementing the numeric priority by 1, then reset wait_ticks.
A practical implementation increments `wait_ticks` for RUNNABLE processes once per timer tick, and whenever
it reaches 31, if priority > 1, decrements priority and resets wait_ticks to 0.
Make sure this update occurs under the correct lock and only once per tick (normally from the timer-tick path).
A process at priority 1 cannot improve further; reset or cap its counter to avoid overflow.
Scheduler-loop iterations are not timer ticks, so do not increment the counter merely on each scan.

## Test caveat
Strict priority scheduling can starve low-priority jobs if aging is absent or incorrectly updated. CPU-bound
test children should generally finish in priority order, but exact order depends on timer timing, output cost,
and the chosen workload. Show wait_ticks/priority changes in logs if the assignment requires visible aging proof.
